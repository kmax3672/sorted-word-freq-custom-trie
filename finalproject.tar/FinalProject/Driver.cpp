#include "Driver.h"
#include "RageVector.h"
#include "TNode.h"
#include "Trie.h"
#include <fstream>
#include <string>
//#include <sstream>
#include <iostream>

using namespace std;
Driver::Driver(){

}


void Driver::drive(){

        Trie* trie = new Trie;

	TNode* blankRoot=new TNode;
	trie->setRoot(blankRoot);

        ifstream inFile;
        inFile.open("inputF.txt");


        string currentLine;
        //stringstream streamA;
        //int wordCount=0;
        string tempStr;
	bool fileOver=false;
	string lastWord="";
	int final=0;
	string X;

        if(!inFile){
		cout<<"Unable" <<endl;
		exit(1);
	}
	while(inFile >> X){
		//cout << X << endl;
		trie->addWord(X,0,trie->getRoot());
	}
	inFile.close();


	RageVector<LinkedList>* wilson = new RageVector<LinkedList>;
	wilson->setData(wilson->getSize());
		
	trie->freakOut(trie->getRoot(), wilson); 
	cout << wilson->getSize() << endl;
	
	int k=wilson->getSize()-1;
	for(k;k>=0;k--){
	//cout << "These words have frequency of: "<< k << endl;
	wilson->getData()[k]->display(k);
	}
	

            
}

Driver::~Driver(){

}
