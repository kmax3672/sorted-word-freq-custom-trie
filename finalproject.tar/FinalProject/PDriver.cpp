#include "Driver.h"
using namespace std;


int main(){
	Driver fuckYourCouch;
	fuckYourCouch.drive();

}
