#ifndef RAGEVECTOR_H__
#define RAGEVECTOR_H__

#include <string>
#include "TNode.h"

class TNode;

template <class T>
class RageVector{

	private:
		int size;
		//TNode** nodeVector;
		T** data;
		

	public:
		RageVector();
		RageVector(T** dataIn, int sizeIn);
		~RageVector();
		void reealloc(RageVector<T> *f);
		RageVector<T>* resize(RageVector<T>* vec, int newSize);
		void dispVec();
		int getSize();
		T** getData();
		void setData(int size);
		
		


};

#include "RageVector.cc"
#endif
