#include "RageVector.h"
#include <iostream>
#include <stdlib.h>

using namespace std;

template <class T>
RageVector<T>::RageVector(){
        data = new T*[30];
        size=30;

}

template<class T>
RageVector<T>::RageVector(T** dataIn, int sizeIn){
	data = dataIn;
	size = sizeIn;
}

template <class T>
int RageVector<T>::getSize(){
        return size;

}

template <class T>
void RageVector<T>::reealloc(RageVector<T> *f){
	cout << "h" << endl;
	size=f->size;
	cout << "i" << endl;
	size*=2;
	cout << "j" << endl;
	data = new T*[size];
	cout << "k" << endl;
	int m=0;
	for(m;m<f->size;m++){
		data[m]=f->data[m];  //WATCH OUT, FOR LOOPS MIGHT OVERLAP
	}
	for(m+1;m<size;m++){
		data[m]=new T;
	}


}

template<class T>
RageVector<T>* RageVector<T>::resize(RageVector<T>* vec, int newSize){
	RageVector<T> *newVec = new RageVector(vec->getData(),newSize);
	//delete vec;	
	return newVec;	
}


template<class T>
void RageVector<T>::dispVec(){
	int i=0;
	cout << size << endl;
	for( i; i<size; i++){
		if(data[i]!=NULL){
		data[i]->display();
		}
	}
}

template<class T>
T** RageVector<T>::getData(){
	return data;
}

template<class T>
void RageVector<T>::setData(int size){
	int i=0;
	for(i;i<size;i++){
		
		data[i]=new T;
	}
}

template <class T>
RageVector<T>::~RageVector() {

} 
