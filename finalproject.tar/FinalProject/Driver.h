#ifndef Driver_H__
#define Driver_H__

class Driver{

	private:

	public:
		Driver();
		~Driver();
		void drive();

};
#endif
